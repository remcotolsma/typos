import fontforge

fillfont = fontforge.open("EaduiFill.sfd")
fillfont.generate("EaduiFill.ttf", flags=("opentype",))
